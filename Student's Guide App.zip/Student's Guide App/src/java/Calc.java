/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Cr7
 */
public class Calc extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();
        String uname=session.getAttribute("uname").toString();
        String sol1="",sol2="",sol3="",sol4="",sol5="",ans1="",ans2="",ans3="",ans4="",ans5="";
          sol1=request.getParameter("a1");
          sol2=request.getParameter("a2");
          sol3=request.getParameter("a3");
          sol4=request.getParameter("a4");
          sol5=request.getParameter("a5");
          ans1=request.getParameter("q1");
          ans2=request.getParameter("q2");
          ans3=request.getParameter("q3");
          ans4=request.getParameter("q4");
          ans5=request.getParameter("q5");
         String[] ans={ans1,ans2,ans3,ans4,ans5}; 
         String[] sol={sol1,sol2,sol3,sol4,sol5};
         int i=0,count=0;
  
         for(i=0;i<5;i++){
             if(ans[i].equals(sol[i]))
                 count++;
         }
         session.setAttribute("score",Integer.toString(count));
         response.sendRedirect("scoredisplay.jsp");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
