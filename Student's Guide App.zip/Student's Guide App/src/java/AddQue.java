/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Cr7
 */
public class AddQue extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         HttpSession session=request.getSession(false);    
        PrintWriter out=response.getWriter();
         int i=Integer.parseInt(session.getAttribute("counter").toString());
         String[] que=new String[i+1];
         String[] ans=new String[(i*3)+1];
         int k=0;
         for(int j=1;j<=i;j++){
             que[j]=request.getParameter("q"+j);
             for(int l=1;l<=3;l++)
                ans[k]=request.getParameter("a"+l);
             
         }
         try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
           int l=1;
           /*for(int j=1;j<=i;j++){
               if(l<=k){
              */ String sql="update discuss set ans1='"+ans[l]+"' where que="+que[1]+";";
               //l+=3;
               stmt.executeUpdate(sql);
               
           //}
         }catch(Exception e){
             out.println(e);
         }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
                String code=request.getParameter("Discode");
        String que=request.getParameter("que");
        PrintWriter out=response.getWriter();
       HttpSession sess=request.getSession(false);
       String allname=(String)sess.getAttribute("uname");  
       String name="";
       String an=request.getParameter("an");
       if(an.equals("Yes"))
           name="Anonymous";
       else
           name=allname;
       try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
           String sql="insert into discuss values('"+name+"','"+code+"','"+que+"',null,null,null);";
            int op=stmt.executeUpdate(sql);
             if(op==1)
                 response.sendRedirect("home.jsp");
             else
                 response.sendRedirect("AddQue.html");
             }
            catch(Exception e){
                    out.println(e);
            }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
