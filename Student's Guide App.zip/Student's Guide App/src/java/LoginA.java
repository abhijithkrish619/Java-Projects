/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Cr7
 */
public class LoginA extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String b2=request.getParameter("New Account");
        String b3=request.getParameter("ForgotPass");
        if(b2!=null)
            response.sendRedirect("signup.html");
        if(b3!=null)
            response.sendRedirect("forgotpass.html");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        PrintWriter out=response.getWriter(); 
        response.setContentType("text/html;charset=UTF-8");
         String uname=request.getParameter("uname");
         String pass=request.getParameter("pass");
         String pass1="";
         try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
            String check="select * from id where uname='"+uname+"';";
            ResultSet rs= stmt.executeQuery(check);
            int c=0;
            while(rs.next()){
                pass1=rs.getString("pass");
                //out.println(abc);
                c++;
            }
            if(c==1){
                if(pass.equals(pass1)){
                HttpSession session=request.getSession();  
                session.setAttribute("uname",uname);  
                request.setAttribute("myname",uname);
               request.getRequestDispatcher("home.jsp").forward(request,response); 
                }
                else{
                    response.sendRedirect("errorpage.jsp");
                }
                }
            else{
                response.sendRedirect("nouser.jsp");
            }
         }
         catch(Exception e){
             System.out.println(e);
             response.sendRedirect("errorpage.jsp");
         }
                
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
