/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Cr7
 */
public class Grades extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session=request.getSession();
        String allname=session.getAttribute("uname").toString();
        PrintWriter out=response.getWriter();
        String b1=request.getParameter("View");
        String b2=request.getParameter("Add");
        String c=request.getParameter("sem");
        if(b1!=null){
             try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
            String check="select * from semscores where uname='"+allname+"' and sem='"+c+"';";
            ResultSet rs= stmt.executeQuery(check);
           int i=0;
            while(rs.next()){
               String uname=rs.getString("uname");
               String sem=rs.getString("sem");
               String c1=rs.getString("c1name");
               String c2=rs.getString("c2name");
               String c3=rs.getString("c3name");
               String c4=rs.getString("c4name");
               String c5=rs.getString("c5name");
               String c6=rs.getString("c6name");
               String g1=rs.getString("c1grade");
               String g4=rs.getString("c4grade");
               String g2=rs.getString("c2grade");
               String g3=rs.getString("c3grade");
               String g5=rs.getString("c5grade");
               String g6=rs.getString("c6grade");
               int cr1=Integer.parseInt(rs.getString("c1cred"));
               int cr2=Integer.parseInt(rs.getString("c2cred"));
               int cr3=Integer.parseInt(rs.getString("c3cred"));
               int cr4=Integer.parseInt(rs.getString("c4cred"));
               int cr5=Integer.parseInt(rs.getString("c5cred"));
               int cr6=Integer.parseInt(rs.getString("c6cred"));
               i++;
              out.println("<html>\n" +
"    <head>\n" +
"        <title>Add Grades</title>\n" +
"        <meta charset=\"UTF-8\">\n" +
"        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
"      <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\n" +
"  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\n" +
"  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\n" +
"  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script>\n" +
"    </head>\n" +
"    <body class=\"container p-3 my-3 bg-dark text-white text-center\">\n" +
"              <h1 class=\"display-3\">Student's Guide</h1><br>\n" +
"              <hr color=\"white\">\n" +
"             <br><br><br><br>");
              out.println("<h1 class=\"display-3\"> Semester: "+sem+"</h1><br>\n");
              out.println("<table class=\"table table-striped table-dark\">\n" +
"  <thead>\n" +
"    <tr>\n" +
"      <th scope=\"col\">#</th>\n" +
"      <th scope=\"col\">Course Name</th>\n" +
"      <th scope=\"col\">Course Credits</th>\n" +
"      <th scope=\"col\">Course Grade</th>\n" +
"    </tr></thead>\n"); 
              out.println("<tbody>\n" +
"    <tr>\n" +
"      <th scope=\"row\">1</th>\n" +
"      <td>"+c1+"</td>\n" +
"      <td>"+cr1+"</td>\n" +
"      <td>"+g1+"</td>\n" +
 
"    </tr>\n" +
"      <th scope=\"row\">2</th>\n" +
"      <td>"+c2+"</td>\n" +
"      <td>"+cr2+"</td>\n" +
"      <td>"+g2+"</td>\n" +
 
"    </tr>\n" +
"      <th scope=\"row\">3</th>\n" +
"      <td>"+c3+"</td>\n" +
"      <td>"+cr3+"</td>\n" +
"      <td>"+g3+"</td>\n" +
 
"    </tr>\n" +
"      <th scope=\"row\">4</th>\n" +
"      <td>"+c4+"</td>\n" +
"      <td>"+cr4+"</td>\n" +
"      <td>"+g4+"</td>\n" +
 
"    </tr>\n" +
"      <th scope=\"row\">5</th>\n" +
"      <td>"+c5+"</td>\n" +
"      <td>"+cr5+"</td>\n" +
"      <td>"+g5+"</td>\n" +
 
"    </tr>\n" +
"      <th scope=\"row\">6</th>\n" +
"      <td>"+c6+"</td>\n" +
"      <td>"+cr6+"</td>\n" +
"      <td>"+g6+"</td>\n" +
 
"    </tr>\n" +
"  </tbody>"+"");
             
              out.println(" </body>\n" +
"</html>\n" +
"");
               
            }
            
               if(i==0)
                   response.sendRedirect("nograde.jsp");
               
             }
            catch(Exception e){
                
                    response.sendRedirect("nograde.jsp");
                    System.out.println(e);
                    }
        }
        if(b2!=null)
            response.sendRedirect("AddGrades.html");
    

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session=request.getSession(false);
        String allname=session.getAttribute("uname").toString();
        PrintWriter out=response.getWriter();
        String b1=request.getParameter("View");
        String b2=request.getParameter("Add");
        String c=request.getParameter("sem");
        String c1=request.getParameter("c1");
        String c2=request.getParameter("c2");
        String c3=request.getParameter("c3");
        String c4=request.getParameter("c4");
        String c5=request.getParameter("c5");
        String c6=request.getParameter("c6");
        String cr1=request.getParameter("cr1");
        String cr2=request.getParameter("cr2");
        String cr3=request.getParameter("cr3");
        String cr4=request.getParameter("cr4");
        String cr5=request.getParameter("cr5");
        String cr6=request.getParameter("cr6");
        String g1=request.getParameter("g1");
        String g2=request.getParameter("g2");
        String g3=request.getParameter("g3");
        String g4=request.getParameter("g4");
        String g5=request.getParameter("g5");
        String g6=request.getParameter("g6");
        float sum=Integer.parseInt(cr1);
             try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
            String sql="insert into semscores values('"+allname+"','"+c+"','"+c1+"','"+g1+"','"+cr1+"','"+c2+"','"+g2+"','"+cr2+"','"+c3+"','"+g3+"','"+cr3+"','"+c4+"','"+g4+"','"+cr4+"','"+c5+"','"+g5+"','"+cr5+"','"+c6+"','"+g6+"','"+cr6+"');";   
            int op=stmt.executeUpdate(sql);
             if(op==1)
                 response.sendRedirect("grades.html");
             else
                 response.sendRedirect("AddGrades.html");
             }
            catch(Exception e){
                
                    response.sendRedirect("nograde.jsp");
                    System.out.println(e);
                    }
        }


    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
