/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Cr7
 */
public class AddFeed extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        processRequest(request, response);
             response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String code=request.getParameter("CourseCode");
           try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
        String sql="select * from coursefeedback where ccode='"+code+"';";
           ResultSet rs=stmt.executeQuery(sql);
           int c=1;
           out.println("<html>\n" +
"    <head>\n" +
"        <title>Add Grades</title>\n" +
"        <meta charset=\"UTF-8\">\n" +
"        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
"      <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\n" +
"  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\n" +
"  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\n" +
"  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script>\n" +
"    </head>\n" +
"    <body class=\"container p-3 my-3 bg-dark text-white text-center\">\n" +
"              <h1 class=\"display-3\">Student's Guide</h1><br>\n" +
"              <hr color=\"white\">\n" +
"             <br><br><br><br>");
              out.println("<h1 class=\"display-3\"> Course Code: "+code+"</h1><br>\n");
              out.println("<table class=\"table table-striped table-dark\">\n" +
"  <thead>\n" +
"    <tr>\n" +
"      <th scope=\"col\">#</th>\n" +
"      <th scope=\"col\">User </th>\n" +
"      <th scope=\"col\">Course FeedBack</th>\n" +
"    </tr></thead>\n"); 
              
           while(rs.next()){
               String feedback=rs.getString("cfeed");
               String who=rs.getString("uname");
               out.println("<tbody>\n" +
"    <tr>\n" +
"      <th scope=\"row\">"+c+"</th>\n" +
"      <td>"+who+"</td>\n" +
"      <td>"+feedback+"</td>\n" +
 
"    </tr>\n" +
"    </tr>\n" +
"  </tbody>"+"");
              out.println(" </body>\n" +
"</html>\n" +
"");
             c++; 
           } 
           if(c==1)
               response.sendRedirect("nocourse.jsp");
           }
            catch(Exception e){
                    System.out.println(e);
                    }
     
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
             response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String code=request.getParameter("CourseCode");
        String feedback=request.getParameter("feedback");
        /*
        'swe2020', 'A very interesting course in which you study about various metrics involved in each software engineering phase. If you concentrate well enough you can do well in this course.'

        */
       HttpSession sess=request.getSession(false);
       String allname=(String)sess.getAttribute("uname");  
       String name="";
       String an=request.getParameter("an");
       if(an.equals("Yes"))
           name="Anonymous";
       else
           name=allname;
       try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
           String sql="insert into coursefeedback values('"+name+"','"+code+"','"+feedback+"');";
            int op=stmt.executeUpdate(sql);
             if(op==1)
                 response.sendRedirect("home.jsp");
             else
                 response.sendRedirect("AddFeed.html");
             }
            catch(Exception e){
                    System.out.println(e);
                    }
     
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
