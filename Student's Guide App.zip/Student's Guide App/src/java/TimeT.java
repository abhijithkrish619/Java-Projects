import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet(name = "uploadImage", urlPatterns = {"/uploadImage"})
@MultipartConfig(maxFileSize = 16177216)//1.5mb
public class TimeT extends HttpServlet {

    PrintWriter out;
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session=request.getSession(false);
        String allname=session.getAttribute("uname").toString();
        PrintWriter out=response.getWriter();
        Integer c=Integer.parseInt(request.getParameter("sem_pick"));
             try{
               Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
            String check="select * from timetable where uname='"+allname+"';";
            ResultSet rs= stmt.executeQuery(check);
           int i=0;
            while(rs.next()){
                int sem=rs.getInt("sem");
                if(sem==c){
             byte[] imgData = rs.getBytes("timeimg");
               String encode = Base64.getEncoder().encodeToString(imgData);
            request.setAttribute("imgBase", encode);
                out.println("<html>\n" +
"    <head>\n" +
"        <title>Add Grades</title>\n" +
"        <meta charset=\"UTF-8\">\n" +
"        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
"      <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\n" +
"  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\n" +
"  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\n" +
"  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script>\n" +
"    </head>\n" +
"    <body class=\"container p-3 my-3 bg-dark text-white text-center\">\n" +
"              <h1 class=\"display-3\">Student's Guide </h1><br>\n" +
"              <hr color=\"white\">\n" +"<h3 class=\"display-\">Semester: "+c+" timetable </h1><br>\n"+
"             <br><br><br><br>");
              out.println("<img src=data:image/jpeg;base64,"+encode+" width=\"1200\" height=\"650\"/>");
              out.println(" </body>\n" +
"</html>\n" +
"");
            }
                else{
                    response.sendRedirect("nograde.jsp");
                    }
            
            }
             
            
               
             }
            catch(Exception e){
                    response.sendRedirect("nott.jsp");
                    System.out.println(e);
                    }
        

    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        int result = 0;
        HttpSession sess=request.getSession();
        String name=sess.getAttribute("uname").toString();
        String c=request.getParameter("sem");
        Part part = request.getPart("tphoto");
        if (part != null) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_guide","root","school");
                PreparedStatement ps = con.prepareStatement("insert into timetable(uname,sem,timeimg) values(?,?,?)");
                InputStream is = part.getInputStream();
                
                ps.setString(1, name);
                ps.setString(2, c);
                ps.setBlob(3, is);
                result = ps.executeUpdate();
                if (result > 0) {
                    response.sendRedirect("home.jsp");
                } else {
                    response.sendRedirect("TimeTable.html?message=Some+Error+Occurred");
                }
            } catch (Exception e) {
                out.println(e);
            }
        }
    }

}