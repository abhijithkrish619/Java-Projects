/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class Ins extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException {
      

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        try{
        String name=request.getParameter("name");
        String email=request.getParameter("email");
        String major=request.getParameter("major");
        String sec_code=request.getParameter("sec_code");
        Double cgpa=Double.parseDouble(request.getParameter("cgpa"));
        String uni=request.getParameter("uni");
        String uname=request.getParameter("uname");
        String pass=request.getParameter("pass");
        String cpass=request.getParameter("cpass");
      
        if(cpass.equals(pass)){
              try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student_guide","root","school");
            Statement stmt=con.createStatement();
           String check1="select * from id where uname='"+uname+"' or email '"+email+"';";
           ResultSet rs1= stmt.executeQuery(check1);
            int c=0;
            while(rs1.next()){
                String abc=rs1.getString("uname");
                c++;
            }
            if(c!=0){
                    response.sendRedirect("erroruname.jsp");
           }else{
            String sql="insert into id values ('"+uname+"' , '"+pass+"' ,'"+sec_code+"' ,'"+name+"','"+email+"','"+major+"','"+cgpa+"','"+uni+"') ;";
            int op=  stmt.executeUpdate(sql);
            if(op == 1){
            response.sendRedirect("index.html");
          }
            }
            stmt.close();
            con.close();
        }catch(Exception r){
            System.out.println(r);
        }
        }
        else{
            response.sendRedirect("errorpage.jsp");
        }
        }catch(Exception se){
            System.out.println(se);
            response.sendRedirect("errorpage.jsp");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
